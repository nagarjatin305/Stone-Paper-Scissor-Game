from tkinter import *
import random
win=Tk()
paper=PhotoImage(file="paper.png")
stone=PhotoImage(file="stone.png")
scissor=PhotoImage(file="scissor.png")
win.geometry('500x500')
l=[stone,paper,scissor]
lb=Label(win,text="My Choice").place(x=65,y=50)
lb=Label(win,text="Computer's Choice").place(x=325,y=50)
def Stone():
    lb=Label(win,image=stone).place(x=20,y=90)
    m=l[random.randint(0,len(l)-1)]
    la=Label(win,image=m).place(x=300,y=90)
    if m==stone:
        Lab=Label(win,text="DRAW",width=15,bg='green',fg='yellow').place(x=200,y=450)
    elif m==paper:
        Lab=Label(win,text="COMPUTER WON",width=15,bg='green',fg='yellow').place(x=200,y=450)
    else:
        Lab=Label(win,text="YOU WON",width=15,bg='green',fg='yellow').place(x=200,y=450)
def Paper():
    lb=Label(win,image=paper).place(x=20,y=90)
    m=l[random.randint(0,len(l)-1)]
    la=Label(win,image=m).place(x=300,y=90)
    if m==paper:
        Lab=Label(win,text="DRAW",width=15,bg='green',fg='yellow').place(x=200,y=450)
    elif m==stone:
        Lab=Label(win,text="YOU WON",width=15,bg='green',fg='yellow').place(x=200,y=450)
    else:
        Lab=Label(win,text="COMPUTER WON",width=15,bg='green',fg='yellow').place(x=200,y=450)
def Scissor():
    lb=Label(win,image=scissor).place(x=20,y=90)
    m=l[random.randint(0,len(l)-1)]
    la=Label(win,image=m).place(x=300,y=90)
    m=l[random.randint(0,len(l)-1)]
    
    la=Label(win,image=m).place(x=300,y=90)
    if m==scissor:
        Lab=Label(win,text="DRAW",width=15,bg='green',fg='yellow').place(x=200,y=450)
    elif m==paper:
        Lab=Label(win,text="YOU WON",width=15,bg='green',fg='yellow').place(x=200,y=450)
    else:
        Lab=Label(win,text="COMPUTER WON",width=15,bg='green',fg='yellow').place(x=200,y=450)
btn=Button(win,text="Stone",command=Stone).place(x=30,y=0)
btn=Button(win,text="Paper",command=Paper).place(x=80,y=0)
btn=Button(win,text="Scissor",command=Scissor).place(x=130,y=0)
win.mainloop()